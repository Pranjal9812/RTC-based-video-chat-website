console.warn("Agora highly suggests not using a string as the user ID.");

const messagesContainer = document.getElementById('messages');
if (messagesContainer) {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

const memberContainer = document.getElementById('members__container');
const memberButton = document.getElementById('members__button');

const chatContainer = document.getElementById('messages__container');
const chatButton = document.getElementById('chat__button');

let activeMemberContainer = false;
let activeChatContainer = false;

if (memberButton) {
    memberButton.addEventListener('click', () => {
        if (activeMemberContainer) {
            memberContainer.classList.add('hidden');
        } else {
            memberContainer.classList.remove('hidden');
        }
        activeMemberContainer = !activeMemberContainer;
    });
}

if (chatButton) {
    chatButton.addEventListener('click', () => {
        if (activeChatContainer) {
            chatContainer.classList.add('hidden');
        } else {
            chatContainer.classList.remove('hidden');
        }
        activeChatContainer = !activeChatContainer;
    });
}

const displayFrame = document.getElementById('stream_box');
const videoFrames = document.querySelectorAll('.video_container');
let userIdInDisplayFrame = null;

const expandVideoFrame = (e) => {
    const child = displayFrame?.children[0];
    if (child) {
        document.getElementById('stream_container').appendChild(child);
    }

    displayFrame.style.display = 'block';
    displayFrame.appendChild(e.currentTarget);
    userIdInDisplayFrame = e.currentTarget.id;

    videoFrames.forEach(frame => {
        if (frame.id !== userIdInDisplayFrame) {
            frame.classList.add('small-frame');
        }
    });
};

videoFrames.forEach(frame => {
    frame.addEventListener('click', expandVideoFrame);
});

const hideDisplayFrame = () => {
    userIdInDisplayFrame = null;
    displayFrame.style.display = null;

    const child = displayFrame?.children[0];
    if (child) {
        document.getElementById('stream_container').appendChild(child);
    }

    videoFrames.forEach(frame => {
        frame.classList.remove('small-frame');
    });
};

if (displayFrame) {
    displayFrame.addEventListener('click', hideDisplayFrame);
}
