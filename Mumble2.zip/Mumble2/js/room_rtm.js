let handleMemberJoined = async (MemberId) => {
    console.log('A new member has joined the room:', MemberId);
    await addMemberToDom(MemberId);

    let members = await channel.getMembers();
    updateMemberTotal(members);

    let {name} = await rtmClient.getUserAttributesByKeys(MemberId, ['name']);
    addBotMessageToDom(`Welcome to the room ${name}! 👋`)
};

let addMemberToDom = async (MemberId) => {
    try {
        // Get user attributes (name)
        let attributes = await rtmClient.getUserAttributesByKeys(MemberId, ['name']);
        let name = attributes.name || 'Unknown'; // Default to 'Unknown' if name is not set
        console.log('Retrieved name for member:', name);

        let membersWrapper = document.getElementById('member__list');
        if (!membersWrapper) {
            console.error('Members list container not found.');
            return;
        }

        // Create and insert member item
        let memberItem = `
            <div class="member__wrapper" id="member__${MemberId}__wrapper">
                <span class="green__icon"></span>
                <p class="member_name">${name}</p>
            </div>
        `;
        membersWrapper.insertAdjacentHTML('beforeend', memberItem);
    } catch (error) {
        console.error('Error adding member to DOM:', error);
    }
};

let updateMemberTotal = (members) => {
    let total = document.getElementById('members__count');
    if (total) {
        total.innerText = members.length; // Ensure this is the correct way to get member count
    } else {
        console.error('Total members count element not found.');
    }
};

let handleMemberLeft = async (MemberId) => {
    removeMemberFromDom(MemberId);

    let members = await channel.getMembers();
    updateMemberTotal(members);
};

let removeMemberFromDom = (MemberId) => {
    let memberWrapper = document.getElementById(`member__${MemberId}__wrapper`);
    let name = memberWrapper.getElementsByClassName('member_name')[0].textContent;
    if (memberWrapper) {
        memberWrapper.remove();
    } else {
        console.error(`Member wrapper with ID member__${MemberId}__wrapper not found.`);

    }
    addBotMessageToDom(`${name} has left the room.`);
};

let getMembers = async () => {
    try {
        let members = await channel.getMembers();
        updateMemberTotal(members); // Update total before adding new members to the DOM

        // Add each member to the DOM
        for (let i = 0; i < members.length; i++) {
            await addMemberToDom(members[i]);
        }
    } catch (error) {
        console.error('Error getting members:', error);
    }
};

let handleChannelMessage = async (messageData, MemberId) => {
    console.log('A new message was received')
    let data = JSON.parse(messageData.text)

    if(data.type === 'chat'){
        addMemberToDom(data.displayName, data.message)

    }

    if(data.type === 'user_left'){
        document.getElementById(`user-container-${data.uid}`).remove();

        if(userIdInDisplayFrame === `user-container-${uid}`){
            displayFrame.style.display = null
    
            for(let i = 0; videoFrames.lenght > i; i++){
                videoFrames[i].style.height = '300px'
                videoFrames[i].style.width = '300px'
            }   
         }
    

    }
}

let sendMessage = async (e) => {
    e.preventDefault()

    let message = e.target.message.value
    channel.sendMessage({text:JSON.stringify({'type':'chat', 'message':message, 'displayName':displayName})})
    addMessageToDom(displayName, message)
    e.target.reset()
}

let addMessageToDom = (name, message) => {
    let messagesWrapper = document.getElementById('messages')

    let newMessage = `<div class="message__wrapper">
                          <div class="message__body">
                              <strong class="message__author">${name}</strong>
                              <p class="message__text">${message}</p>
                        </div>
                      </div>`

    messagesWrapper.insertAdjacentHTML('beforeend', newMessage)

    let lastMessage = document.querySelector('#messages .message__wrapper:last-child')
    if(lastMessage){
        lastMessage.scrollIntoView()
    }
}


let addBotMessageToDom = (botMessage) => {
    let messagesWrapper = document.getElementById('messages')

    let newMessage = `<div class="message__wrapper">
                        <div class="message__body__bot">
                            <strong class="message__author__bot">🤖 Mumble Bot</strong>
                            <p class="message__text__bot">${botMessage}</p>
                        </div>
                      </div>`

    messagesWrapper.insertAdjacentHTML('beforeend', newMessage)

    let lastMessage = document.querySelector('#messages .message__wrapper:last-child')
    if(lastMessage){
        lastMessage.scrollIntoView()
    }
}



let leaveChannel = async () => {
    try {
        await channel.leave();
        await rtmClient.logout();
    } catch (error) {
        console.error('Error leaving the channel:', error);
    }
};

window.addEventListener('beforeunload', leaveChannel);
let messageForm = document.getElementById('message__form')
messageForm.addEventListener('submit', sendMessage)

// Ensure the following code is executed after initialization
// Example initialization function could look like this:
const initialize = async () => {
    // Your RTM and channel initialization logic
    await joinRoomInit();
    await getMembers();
};

initialize();
