document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('lobby__form');

    if (!form) {
        console.error('Form not found');
        return;
    }

    const displayName = sessionStorage.getItem('display_name');
    if (displayName) {
        form.name.value = displayName;
    }

    form.addEventListener('submit', (e) => {
        e.preventDefault();

        const nameValue = e.target.name.value.trim();
        const roomValue = e.target.room.value.trim();

        if (!nameValue || !roomValue) {
            console.error('Name or Room input is empty');
            return;
        }

        // Save display name to session storage
        sessionStorage.setItem('display_name', nameValue);

        // Generate invite code if room value is empty
        let inviteCode = roomValue || String(Math.floor(Math.random() * 10000));

        // Redirect to the room page
        window.location.href = `room.html?room=${encodeURIComponent(inviteCode)}`;
    });
});
